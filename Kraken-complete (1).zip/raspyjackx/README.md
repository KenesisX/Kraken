# RaspyJack-X

A touch-first successor to RaspyJack. The original crams everything onto a
1.44" LCD with a 5-way joystick; RaspyJack-X is built around a real
capacitive touchscreen, a data-driven menu you edit in YAML, a live output
console, and a telemetry bar (IP / CPU / temp / battery / clock). It's
designed to drop straight into a 3D-printed cyberdeck shell and to grow into
your ICU / Omni-RF command platform.

> **Authorized testing only.** Everything here runs standard, publicly
> available tools against whatever target you configure. Only point it at
> networks and devices you own or have written permission to assess.

---

## 1. What you get

| Piece | File | Does |
|------|------|------|
| Touch UI | `raspyjackx/ui.py` | Fullscreen tabbed launcher, console, status bar |
| Command runner | `raspyjackx/runner.py` | Streams live output via `QProcess`, Stop button, one-at-a-time |
| Telemetry | `raspyjackx/sysmon.py` | IP/CPU/temp/battery, PiSugar + generic UPS aware |
| Menu | `raspyjackx/tools.yaml` | **The menu is data** — add tools without touching code |
| Theme | `raspyjackx/theme.py` | One accent colour re-tints everything; big hit targets |
| Installer | `install.sh` | apt deps, venv fallback, systemd kiosk service |

---

## 2. Hardware (locked build)

This build is fixed to the following. The profiles and setup scripts assume
exactly this gear.

| Role | Part | Chipset / note |
|------|------|----------------|
| Brain | **Raspberry Pi 5 (8 GB)** | A76 @2.4 GHz — handles SDR DSP + cracking + multi-tool |
| Wi-Fi | **Alfa AWUS036AC** | RTL8812AU, dual-band — needs the 8812au DKMS driver (`setup_awus036ac.sh`) |
| SDR | **RTL-SDR Blog V4** | R828D tuner — needs the rtl-sdr-blog driver fork (`setup_rtlsdr_v4.sh`) |

> **Two driver gotchas, both handled by the scripts:**
> - The AWUS036AC's in-kernel driver does **not** do monitor mode/injection.
>   `setup_awus036ac.sh` installs the maintained 8812au DKMS driver and a
>   `rjx-mon` helper to toggle monitor mode.
> - The V4 needs the **rtl-sdr-blog** driver, not apt's osmocom package, or you
>   get no signal above ~250 MHz. `setup_rtlsdr_v4.sh` purges the wrong one,
>   builds the right one, and blacklists the kernel DVB driver.

### Touchscreen (pick one)
- **Pimoroni HyperPixel 4.0** (800×480, capacitive, DPI over GPIO) — crispest,
  no HDMI cable, best for a clean cyberdeck face. *Note: it consumes most GPIO,
  so plan HATs around it or use the CM4 carrier's extra pins.*
- **Waveshare 4" / 4.3" DSI capacitive** — leaves GPIO free, uses the DSI
  ribbon, great middle ground.
- **Waveshare 3.5" DPI (C)** — cheapest capacitive option; UI still fits.
- 5"–7" DSI if you want room for the ICU multi-pane layout later.

### Interface map (as configured in tools.yaml)
- `wlan0` — the Pi 5's **onboard** Wi-Fi (leave for management/SSH).
- `wlan1` — the **AWUS036AC**; this is what the Wireless tab scans and flips to
  monitor mode. Plug it into a **USB 3 (blue) port**.
- `eth0` — wired NIC facing the target LAN.
- **Keep the RTL-SDR V4 on a USB 2 port or a short shielded extension** — the
  Pi 5's USB3 bus radiates and desenses the SDR badly if they're adjacent.

### Power
- **PiSugar 3 Plus** (5000 mAh) — `sysmon.py` reads its battery % and charge
  state automatically over its local socket. Clean, pogo-pin mount.
- Or a **Geekworm/Waveshare UPS HAT** (registers a `power_supply` node, also
  auto-detected).
- For long field runs: 2× 18650 pack + a 5 V/3 A boost board.

### Storage & housekeeping
- **A2-rated microSD** minimum; on Pi 5, an **NVMe via the M.2 HAT** is a huge
  quality-of-life win for captures and wordlists.
- **RTC module** (DS3231) so timestamps on loot are correct offline.
- A **GPIO momentary button** wired to a safe-shutdown script, plus a status
  LED or two.
- Small **5 V blower/fan** — the Pi 5 throttles under sustained SDR + cracking;
  the status bar turns the temp field 🔥 at 75 °C so you see it coming.

### Case (you already have the printer)
- Print a two-piece shell on the **A1 mini**: front bezel sized to your screen
  cutout, rear tray for Pi + PiSugar + SDR, side slots for the NICs' USB/SMA.
  Keep the SDR bay away from the Pi's USB3 (USB3 noise desenses RTL-SDR —
  shield it or move it). This mirrors your existing cyberdeck layout, so the
  mounting pattern can be shared.

---

## 3. OS setup

1. Flash **Raspberry Pi OS Bookworm (64-bit)** — or **Kali Linux ARM** if you
   want the offensive toolchain preloaded.
2. First boot, enable the screen per its vendor overlay in `/boot/firmware/config.txt`
   (HyperPixel/Waveshare each ship a one-line `dtoverlay=`).
3. Enable I2C/SPI if your UPS or RTC needs it (`sudo raspi-config`).
4. Boot to desktop (needed for the Qt fullscreen surface). For a true kiosk,
   you can later switch to a minimal `cage`/`labwc` session — the systemd unit
   targets `graphical.target` either way.

---

## 4. Install

```bash
unzip raspyjackx.zip && cd raspyjackx
chmod +x install.sh hw_setup/*.sh

# one-time driver setup for the locked hardware:
sudo ./hw_setup/setup_awus036ac.sh     # AWUS036AC monitor-mode driver + rjx-mon
sudo ./hw_setup/setup_rtlsdr_v4.sh     # RTL-SDR V4 driver; REBOOT after this

./install.sh
sudo systemctl enable --now raspyjackx     # start now + on every boot
```

Dev run on any desktop (no touchscreen needed):

```bash
cd ~/raspyjackx
python3 -m raspyjackx.main --windowed
```

---

## 5. Make it yours — the menu is just YAML

Open `raspyjackx/tools.yaml`. Set your interface and target once:

```yaml
variables:
  iface: "eth0"
  subnet: "10.10.0.0/24"
  target: "10.10.0.5"
```

Add a tool — label, command, and whether to confirm first:

```yaml
- label: "Full TCP + scripts"
  cmd: "nmap -p- -sV -sC {target} -oN {outdir}/full.txt"
  confirm: true
```

- `{placeholders}` expand from `variables:` at launch.
- `confirm: true` pops a yes/no pad — use it for anything that changes state.
- `shell: true` runs through `bash -lc` so pipes/redirects/`$(…)` work.

Hit the ⟳ button to reload the file; restart the app to pick up new tabs.

---

## 6. Scope guard + engagement logging (built in)

Two things turn this from a gadget into something you can run on a client site:

**Scope guard.** Set the engagement's allowed networks in `tools.yaml`:

```yaml
scope:
  - "10.50.0.0/16"
engagement: "acme-internal-nov"
```

Before any command runs, RaspyJack-X pulls every literal IP/CIDR out of it and
checks them against `scope`. Aim something at an address outside scope and you
get a red **Out of scope** block with an explicit "Override & run" you have to
consciously choose (and the override is logged). Empty `scope:` = allow all
(lab mode). Loopback/multicast are ignored; hostnames pass through (they can't
be resolved offline) so keep targets as IPs when you want hard enforcement.

**Session logging.** Every launch opens an engagement folder:

```
~/loot/acme-internal-nov/
  session-20261107-1903.jsonl   # machine-readable event log
  session-20261107-1903.log     # human transcript: each command + full output
```

Finish the job, zip the folder — that's your evidence trail for the report,
with timestamps and exact commands. The **Loot** tab browses it on-device.

## 7. Galaxy Watch / phone companion

No Android app to build — it rides **ntfy** (push) and a tiny **HTTP server** on
the Pi, both stdlib, both already wired in.

**Push alerts to your wrist.** Install the ntfy app on your phone, subscribe to a
secret topic, and set it in `tools.yaml`:

```yaml
notify:
  topic: "strikeback-rjx-7f3a9c"          # keep this secret
  public_url: "http://10.44.0.1:8088"      # enables the Stop button on alerts
companion:
  token: "a-long-random-string"
```

Now your Galaxy Watch buzzes when a command **starts** (with a **Stop** button
right on the notification), **finishes** (with the exit code), when an
**out-of-scope attempt is blocked**, or when the **battery gets low**.

**Live control page.** Open `http://<pi-ip>:8088` in the watch browser for a
round-screen readout — engagement, IP, temp, battery, the running command — plus
big **STOP** and **SHUTDOWN** buttons.

**Security.** The only write endpoints are stop/shutdown, gated by the token.
Run the companion on the **Pi's own hotspot or a VPN**, not a client LAN, and set
a real token. Arbitrary remote tool-launch is deliberately *not* exposed.

## 8. On-screen variables editor (no SSH, no keyboard)

Tap **✎ VARS** at the top of the left rail. Every variable from `tools.yaml`
(`target`, `bssid`, `channel`, `domain`, `wlan`, wordlists, …) is listed; tap a
value to edit it with the built-in touch keyboard (letters, digits, and the
`. : / - _ @` a MAC/IP/URL needs, plus Shift for uppercase hex). Saved values
persist to `~/.config/raspyjackx/vars.json` and apply to the **next** command —
no restart. This is what the WiFi-Atk / AD / NFC tabs read, so you can retarget
an engagement entirely from the touchscreen.

## 9. Logo assets

`assets/` ships the logo as vector + ready rasters:

- `logo.svg` — the neon bomb-X mark (source)
- `logo-16…1024.png`, `icon-256.png`, `icon-512.png` — app icons
- `favicon.ico` — multi-size (16/32/48/64/256) for web
- `logo_lockup.svg` / `logo_lockup.png` — mark + **STRIKEBACK // RASPYJACK-X** wordmark
- `export_logo.sh` — regenerate the pack (`sudo apt install librsvg2-bin imagemagick`)

Drop `logo-1024.png` straight into the Shopify store / stickers; `favicon.ico`
onto the Strikeback site.

## 10. Academy — the cert reference (🎓 LEARN)

Tap **🎓 LEARN** in the left rail. It's a browsable command + technique
reference mapped to the OffSec certification paths — KLCP, OSCP, OSWP, OSEP,
OSWA, OSWE, OSED, OSEE, OSDA, OSTH, OSIR, OSCC, OSAI. Pick a cert on the left;
each module shows the commands you learn with a one-line note, and a **Run**
button that fills `<ip>/<url>/<domain>/…` from your VARS and executes it
(scope-checked + logged, same as any tool). Concept-only lines (prefixed `#`)
are reference, no Run button.

It's **lazy-loaded** — `academy.yaml` is parsed only when you first open it, so
it adds nothing to boot or the running footprint. Edit `academy.yaml` to add
your own cert notes, playbooks, or team runbooks; it's pure data.

Performance note: the deck is tuned to run hard but stay smooth — pages are
pre-built and switched instantly, the Academy and the tool commands are
lazy/data-driven, and heavy GUI tools (gqrx, URH, Burp/ZAP, GNU Radio) launch
as separate processes so the touch UI never blocks.

## 11. Reports (⎙ REPORT) and profiles (⇅ PROFILE)

**⎙ REPORT** turns the current engagement's session log into a findings draft —
a styled `report-*.md` + `report-*.html` (black/red, Print-to-PDF ready) written
into the loot folder, with a summary (commands run, ok/failed, scope overrides,
blocked, active time), a full activity timeline, and a "Findings (fill in)"
section. If `wkhtmltopdf` or `pandoc` is installed it also drops a `.pdf`. One
tap closes the loop: LEARN → run tools → deliverable.

**⇅ PROFILE** switches tool loadouts without a restart. It lists `tools.yaml`
plus any `tools*.yaml` and `profiles/*.yaml` beside it; tap one to reload the
whole menu. Ships with `profiles/tools-wifi.yaml` (wireless/WiFi-Atk/BLE) and
`profiles/tools-recon.yaml` (recon/scan/web) as focused examples — copy one to
build per-engagement loadouts. Each profile carries its own engagement name,
scope, and variables.

## 12. Setup wizard · findings classifier · cloud sync · Android

- **First-run wizard** — on the first boot (no overrides saved yet) a setup
  screen sets engagement, scope, target/domain, Wi-Fi interface, and the watch
  ntfy topic by touch, then persists them. Change anything later in ✎ VARS.
- **Findings auto-classifier** — ⎙ REPORT now scans the session transcript and
  tags likely findings by severity (CRITICAL→INFO): MS17-010, nmap VULNERABLE,
  sqlmap injection, nuclei criticals/highs, CVEs, PMKID, open ports. Heuristic —
  confirm before you report, but it front-loads the write-up.
- **Cloud sync** — Loot tab has `rsync -az` over SSH and `scp` to `{sync_dest}`
  so loot + reports push to your vault when you're back online.
- **Android OffSec** — Mobile tab drives a test device over ADB: list/pull
  packages, aapt/apktool/jadx, secrets grep, Frida, Objection, logcat, MobSF.

**Not included, by design:** cell-site simulators / IMSI catchers (illegal
interception + impersonating a carrier), jam/spoof/spam RF, and
phishing/credential-harvesting tooling.

## 13. Strikeback demo page

`strikeback_rjx.html` (in the repo root when exported) is a self-contained
landing + live-demo page for the product — hero, feature grid, and the clickable
interface — ready to drop on the Strikeback site.

## 14. Where to take it next (roadmap hooks already in place)

- **Loot browser tab** — a category that lists/greps `{outdir}` so you can
  review captures on-device.
- **On-screen keyboard** — add `matchbox-keyboard` or wire a Qt virtual
  keyboard so you can edit `target` from the touchscreen, no SSH.
- **Profiles** — ship multiple `tools-*.yaml` (internal / wireless / SDR) and
  a selector; `RJX_CONFIG` already lets you swap them.
- **ICU integration** — the runner emits every line as a Qt signal, so piping
  output into your unified command platform's log pane is a direct hookup.
  Long-term, the same `tools.yaml` schema can drive both the on-device touch
  menu and the ICU desktop tabs — one source of truth.
- **Omni-RF** — the SDR category is where ADS-B/AIS/war-drive launchers live;
  point them at your Soapy/RTL pipeline.
- **Safe-shutdown button** — bind a GPIO press to the existing
  `sudo shutdown -h now` entry via a tiny `gpiozero` watcher.

---

## 7. Troubleshooting

| Symptom | Fix |
|--------|-----|
| Blank screen, service restarts | UI needs a display; confirm `DISPLAY=:0` and that you boot to desktop |
| `qt.qpa.plugin` error on dev box | `export QT_QPA_PLATFORM=offscreen` (headless) or install a desktop |
| Battery shows `🔌 ext` | No PiSugar/UPS detected — that's fine on wall power |
| Temp hits 🔥 under load | Add the fan; Pi 5 throttles hard on sustained SDR+crack |
| Tool button does nothing | That binary isn't installed / not on PATH — console shows the error |
```
